StatBot Plugin - Build instructions

1) Requirements:
   - Java JDK 17
   - Maven
   - Spigot/Paper API available to Maven (the POM uses spigot-api 1.20.4 snapshot as 'provided')

2) Build:
   - unzip this project
   - edit src/main/resources/config.yml to set your MySQL info
   - run: mvn package
   - find the compiled jar in target/statbot-1.0-SNAPSHOT.jar
   - put jar in your server plugins/ folder and start the server

3) Database:
   - Run the SQL in sql/schema.sql on your MySQL server or let the plugin create tables automatically.

4) Notes:
   - If your server uses a different API version, update the spigot-api version in pom.xml accordingly.
   - For support, reply here with any error logs and I'll help debug.
