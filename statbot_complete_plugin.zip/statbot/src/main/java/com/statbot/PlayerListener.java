package com.statbot;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.entity.PlayerDeathEvent;

import java.sql.SQLException;
import java.time.Instant;
import java.util.UUID;

public class PlayerListener implements Listener {
    private final Database db;

    public PlayerListener(Database db) { this.db = db; }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        String uuid = e.getPlayer().getUniqueId().toString();
        String name = e.getPlayer().getName();
        long now = Instant.now().getEpochSecond();
        try { db.playerJoin(uuid, name, now); } catch (SQLException ex) { ex.printStackTrace(); }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        String uuid = e.getPlayer().getUniqueId().toString();
        long now = Instant.now().getEpochSecond();
        try { db.playerQuit(uuid, now); } catch (SQLException ex) { ex.printStackTrace(); }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        if (e.getEntity().getKiller() != null) {
            UUID killer = e.getEntity().getKiller().getUniqueId();
            try { db.addKill(killer.toString()); } catch (SQLException ex) { ex.printStackTrace(); }
        }
    }
}
