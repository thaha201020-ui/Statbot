package com.statbot;

import org.bukkit.plugin.java.JavaPlugin;
import java.time.Instant;

public class StatBot extends JavaPlugin {
    private static StatBot instance;
    private Database database;
    private long serverStartEpoch;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        database = new Database(getConfig());
        try {
            database.connect();
            database.createTables();
        } catch (Exception e) {
            getLogger().severe("Database connection failed: " + e.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        getServer().getPluginManager().registerEvents(new PlayerListener(database), this);
        serverStartEpoch = Instant.now().getEpochSecond();
        getLogger().info("StatBot enabled");
    }

    @Override
    public void onDisable() {
        if (database != null) database.close();
        getLogger().info("StatBot disabled");
    }

    public static StatBot getInstance() { return instance; }
    public Database getDatabase() { return database; }
    public long getServerStartEpoch() { return serverStartEpoch; }
}
