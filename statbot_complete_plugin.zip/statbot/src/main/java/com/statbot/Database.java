package com.statbot;

import org.bukkit.configuration.file.FileConfiguration;
import java.sql.*;

public class Database {
    private final String host, database, user, pass;
    private Connection conn;

    public Database(FileConfiguration cfg) {
        host = cfg.getString("mysql.host", "localhost:3306");
        database = cfg.getString("mysql.database", "minecraft");
        user = cfg.getString("mysql.user", "root");
        pass = cfg.getString("mysql.password", "");
    }

    public void connect() throws SQLException {
        String url = "jdbc:mysql://" + host + "/" + database + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
        conn = DriverManager.getConnection(url, user, pass);
    }

    public void createTables() throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS players ("
                + "uuid VARCHAR(36) PRIMARY KEY, "
                + "name VARCHAR(36), "
                + "playtime BIGINT DEFAULT 0, "
                + "last_join BIGINT DEFAULT 0, "
                + "kills INT DEFAULT 0"
                + ")";
        try (Statement st = conn.createStatement()) { st.executeUpdate(sql); }
    }

    public void playerJoin(String uuid, String name, long now) throws SQLException {
        String q = "INSERT INTO players (uuid, name, last_join) VALUES (?,?,?) ON DUPLICATE KEY UPDATE name=?, last_join=?";
        try (PreparedStatement ps = conn.prepareStatement(q)) {
            ps.setString(1, uuid);
            ps.setString(2, name);
            ps.setLong(3, now);
            ps.setString(4, name);
            ps.setLong(5, now);
            ps.executeUpdate();
        }
    }

    public void playerQuit(String uuid, long now) throws SQLException {
        String q = "SELECT last_join, playtime FROM players WHERE uuid=?";
        try (PreparedStatement ps = conn.prepareStatement(q)) {
            ps.setString(1, uuid);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    long lastJoin = rs.getLong("last_join");
                    long playtime = rs.getLong("playtime");
                    long delta = Math.max(0, now - lastJoin);
                    String u = "UPDATE players SET playtime=?, last_join=0 WHERE uuid=?";
                    try (PreparedStatement ups = conn.prepareStatement(u)) {
                        ups.setLong(1, playtime + delta);
                        ups.setString(2, uuid);
                        ups.executeUpdate();
                    }
                }
            }
        }
    }

    public void addKill(String uuid) throws SQLException {
        String q = "UPDATE players SET kills = kills + 1 WHERE uuid = ?";
        try (PreparedStatement ps = conn.prepareStatement(q)) { ps.setString(1, uuid); ps.executeUpdate(); }
    }

    // For other components (not used directly by plugin)
    public ResultSet topPlaytime(int limit) throws SQLException {
        PreparedStatement ps = conn.prepareStatement("SELECT name, playtime FROM players ORDER BY playtime DESC LIMIT ?");
        ps.setInt(1, limit);
        return ps.executeQuery();
    }

    public ResultSet topKills(int limit) throws SQLException {
        PreparedStatement ps = conn.prepareStatement("SELECT name, kills FROM players ORDER BY kills DESC LIMIT ?");
        ps.setInt(1, limit);
        return ps.executeQuery();
    }

    public void close() {
        try { if (conn != null && !conn.isClosed()) conn.close(); } catch (SQLException ignored) {}
    }
}
